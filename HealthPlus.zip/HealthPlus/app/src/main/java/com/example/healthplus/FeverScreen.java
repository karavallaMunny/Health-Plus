package com.example.healthplus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;


public class FeverScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fever_screen);
        TextView fever=(TextView) findViewById(R.id.fever);

        fever.setText("paracetemol\nAspirin\nIbuprofen\nAcetaminophen(Tylenol)\nNaproxen\n");

    }
}