package com.example.healthplus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class PainReliefScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pain_relief_screen);
        TextView pain=(TextView) findViewById(R.id.painrelief);
        pain.setText("Aspirin\nIbuprofen\nAcetaminophen(Tylenol)\nNaproxen\nCodeine\nHydrocodone\nOxycodone\nFentanyl");
    }
}