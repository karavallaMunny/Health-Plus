package com.example.healthplus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class BacterialInfectionScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bacterial_infection_screen);
        TextView bacterialInfection=(TextView) findViewById(R.id.bacterial);
        bacterialInfection.setText("Pencillin\nAmoxicillin\nCiprofloxacin\nDoxycycline\nMetronidazole\nAzithromycin\nTetracycline\n");
    }
}