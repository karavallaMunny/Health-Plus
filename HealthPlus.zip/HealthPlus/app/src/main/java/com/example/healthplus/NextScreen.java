package com.example.healthplus;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class NextScreen extends AppCompatActivity {
    CheckBox cb1,cb2,cb3,cb4,cb5,cb6,cb7,cb8,cb9,cb10,cb11,cb12;
    Button btnReset,btnSubmit;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next_screen);
        cb1 = findViewById(R.id.checkbox1);
        cb2 = findViewById(R.id.checkbox2);
        cb3 = findViewById(R.id.checkbox3);
        cb4 = findViewById(R.id.checkbox4);
        cb5 = findViewById(R.id.checkbox5);
        cb6 = findViewById(R.id.checkbox6);
        cb7 = findViewById(R.id.checkbox7);
        cb8 = findViewById(R.id.checkbox8);
        cb9 = findViewById(R.id.checkbox9);
        cb10 = findViewById(R.id.checkbox10);
        cb11=findViewById(R.id.checkbox11) ;
        cb12=findViewById(R.id.checkbox12);
        btnReset = findViewById(R.id.reset);
        btnSubmit = findViewById(R.id.submit);
        btnSubmit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                StringBuffer result = new StringBuffer();
                result.append("My expertise:");
                if (cb1.isChecked()) {
                    result.append("\n" + cb1.getText().toString());

                }
                if (cb2.isChecked()) {
                    result.append("\n" + cb2.getText().toString());

                }
                if (cb3.isChecked()) {
                    result.append("\n" + cb3.getText().toString());

                }
                if (cb4.isChecked()) {
                    result.append("\n" + cb4.getText().toString());

                }
                if (cb5.isChecked()) {
                    result.append("\n" + cb5.getText().toString());

                }
                if (cb6.isChecked()) {
                    result.append("\n" + cb6.getText().toString());

                }
                if (cb7.isChecked()) {
                    result.append("\n" + cb7.getText().toString());

                }
                if (cb8.isChecked()) {
                    result.append("\n" + cb8.getText().toString());

                }
                if (cb9.isChecked()) {
                    result.append("\n" + cb9.getText().toString());

                }
                if (cb10.isChecked()) {
                    result.append("\n" + cb10.getText().toString());

                }
                if (cb11.isChecked()) {
                    result.append("\n" + cb11.getText().toString());

                }
                if (cb12.isChecked()) {
                    result.append("\n" + cb11.getText().toString());

                }

            }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cb1.isChecked())
                    cb1.setChecked(false);
                if (cb2.isChecked())
                    cb2.setChecked(false);
                if (cb3.isChecked())
                    cb3.setChecked(false);
                if (cb4.isChecked())
                    cb4.setChecked(false);
                if (cb5.isChecked())
                    cb5.setChecked(false);
                if (cb6.isChecked())
                    cb7.setChecked(false);
                if (cb8.isChecked())
                    cb8.setChecked(false);
                if (cb9.isChecked())
                    cb9.setChecked(false);
                if (cb10.isChecked())
                    cb10.setChecked(false);
                if (cb11.isChecked())
                    cb11.setChecked(false);
                if (cb12.isChecked())
                    cb12.setChecked(false);


            }
        });
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb1.isChecked()) {
                    Intent intent = new Intent(NextScreen.this, FeverScreen.class);
                    startActivity(intent);
                }
                else if(cb2.isChecked()){
                    Intent intent=new Intent(NextScreen.this,Allergy.class);
                    startActivity(intent);
                }
                else if(cb3.isChecked()){
                    Intent intent=new Intent(NextScreen.this,PainReliefScreen.class);
                    startActivity(intent);
                }
                else if(cb4.isChecked()){
                    Intent intent=new Intent(NextScreen.this,CoughScreen.class);
                    startActivity(intent);
                }
                else if(cb5.isChecked()){
                    Intent intent=new Intent(NextScreen.this,ColdScreen.class);
                    startActivity(intent);
                }
                else if(cb6.isChecked()){
                    Intent intent=new Intent(NextScreen.this,DiabetesScreen.class);
                    startActivity(intent);
                }
                else if(cb7.isChecked()){
                    Intent intent=new Intent(NextScreen.this,InflammationScreen.class);
                    startActivity(intent);
                }
                else if(cb8.isChecked()){
                    Intent intent=new Intent(NextScreen.this,PanicScreen.class);
                    startActivity(intent);
                }
                else if(cb9.isChecked()){
                    Intent intent=new Intent(NextScreen.this,DepressionScreen.class);
                    startActivity(intent);
                }
                else if(cb10.isChecked()){
                    Intent intent=new Intent(NextScreen.this,BacterialInfectionScreen.class);
                    startActivity(intent);
                }
                else if(cb11.isChecked()){
                    Intent intent=new Intent(NextScreen.this,OthersScreen.class);
                    startActivity(intent);
                }
                else if(cb12.isChecked()){
                    Intent intent=new Intent(NextScreen.this,allMed.class);
                    startActivity(intent);
                }

            }
        });
        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(NextScreen.this,NextScreen.class);
                startActivity(intent);
            }
        });



    }
}