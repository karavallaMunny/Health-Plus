package com.example.healthplus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class PanicScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_panic_screen);
        TextView panic=(TextView) findViewById(R.id.panic);
        panic.setText("Lorazepam\nClonazepam\nDuloxetine\nVenlafaxine\nEscitalopram\nSertraline");

    }
}