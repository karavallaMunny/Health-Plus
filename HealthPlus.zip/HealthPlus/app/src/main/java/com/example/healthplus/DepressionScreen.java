package com.example.healthplus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;


public class DepressionScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_depression_screen);
        TextView depr=(TextView) findViewById(R.id.depression);
        depr.setText("Mitrazapine\n");
    }
}