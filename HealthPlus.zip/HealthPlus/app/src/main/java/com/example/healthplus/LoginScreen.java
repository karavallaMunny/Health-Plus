package com.example.healthplus;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class LoginScreen extends AppCompatActivity {
    EditText uname,pass;

    Button Login;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);
        uname=(EditText)findViewById(R.id.edittextusername);
        pass=(EditText)findViewById(R.id.edittextPssword);

        Login.findViewById(R.id.Login) ;
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String uname2,pass2;
                uname2=uname.getText().toString();
                pass2=pass.getText().toString();
                if(uname2.equals("person")&&pass2.equals("pass123")) {


                    Intent intent = new Intent(LoginScreen.this, NextScreen.class);
                    startActivity(intent);
                }

            }
        });

    }
}
