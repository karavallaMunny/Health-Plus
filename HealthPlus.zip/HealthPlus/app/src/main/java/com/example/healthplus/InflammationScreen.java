package com.example.healthplus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;


public class InflammationScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inflammation_screen);
        TextView inflammation=(TextView) findViewById(R.id.inflammation);
        inflammation.setText("Ibuprofen\nNaproxen\n");
    }
}