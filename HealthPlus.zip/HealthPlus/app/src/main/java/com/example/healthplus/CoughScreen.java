package com.example.healthplus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;


public class CoughScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cough_screen);
        TextView cough=(TextView) findViewById(R.id.cough);
        cough.setText("Dextromethorphan(DM)\nCodeine\nHydrocodone\n");
    }
}