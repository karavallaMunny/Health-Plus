package com.example.healthplus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;


public class OthersScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_others_screen);
        TextView other=(TextView) findViewById(R.id.others);
        other.setText("The above mentioned symptoms are not there\nTry consulting a doctor\nTHANK YOU");
    }
}