package com.example.healthplus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class ColdScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cold_screen);
        TextView cold=(TextView) findViewById(R.id.cold);
        cold.setText("Cetrezine\nBrompheniramine\nAcrivastine\n");
    }
}