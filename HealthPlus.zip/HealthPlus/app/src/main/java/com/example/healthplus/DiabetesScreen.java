package com.example.healthplus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;



public class DiabetesScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diabetes_screen);
        TextView diabetes=(TextView) findViewById(R.id.diabetes);
        diabetes.setText("Insulin\nMetformin\n");
    }
}