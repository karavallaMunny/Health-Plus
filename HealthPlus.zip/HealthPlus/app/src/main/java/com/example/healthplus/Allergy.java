package com.example.healthplus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Allergy extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_allergy);
        TextView allergy=(TextView) findViewById(R.id.allergy);
        allergy.setText("Laratadine(Claritin)\nFexofenadine(Allegra)\nCetirizine(Zyrtec)\nDiphenhydramine(Benadryl)");
    }
}