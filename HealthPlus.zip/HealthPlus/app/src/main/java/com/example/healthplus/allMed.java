package com.example.healthplus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class allMed extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_med);
    }
}