package com.example.healthplus;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterScreen extends AppCompatActivity {
    EditText username,password,cpassword;

    Button register, home;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_screen);
        username=(EditText)findViewById(R.id.edittextUsername);
        password=(EditText)findViewById(R.id.edittextPassword);
        cpassword=(EditText)findViewById(R.id.edittextConformPassword);

        register = findViewById(R.id.Register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String uname1,pass1,cpass1;
                uname1=username.getText().toString();
                pass1=password.getText().toString();
                cpass1=cpassword.getText().toString();
                if(uname1.equals("person")&&pass1.equals("pass123")&&cpass1.equals("pass123")) {
                    Intent intent = new Intent(RegisterScreen.this, NextScreen.class);
                    startActivity(intent);
                    Toast.makeText(RegisterScreen.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                }



            }
        });
        home = findViewById(R.id.Home);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RegisterScreen.this, HomeScreen.class);
                startActivity(intent);
            }
        });

    }
}